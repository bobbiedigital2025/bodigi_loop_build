# Product Development Requirements (PDR) – BoDiGi Learn & Earn Platform
> Engineered for automation agents like Copilot or Replit

---

## 🧠 What the App Must Do

- Automate brand creation, MVP building, marketing asset generation
- Create a quiz-based reward system tailored to the MVP
- Convert learners into customers
- Collect leads and purchases in a centralized CRM system (Supabase)

---

## 🧱 Modules Overview

1. Branding Builder
2. MVP Builder (must include 5 paid features)
3. Marketing Builder (generates content + funnels)
4. Contact Hub (collects all leads and signups)
5. Learn & Earn Loop Builder (personalized quiz system)

---

## 📇 CRM Integration (Contact Hub)

### Tables
- `contacts`: stores name, email, origin, owner, lead status
- `form_submissions`: generic entry storage
- `subscriptions`: links to Stripe metadata + plan + coupon

### Logic
- Every time someone:
  - Starts a loop → entry stored with `entry_type: learn_and_earn`
  - Buys an MVP → stored with `entry_type: mvp_checkout`, `status: customer`

- Platform owner can:
  - View all leads
  - Filter by customer/owner_id
  - Trigger retargeting

---

## 🔁 Loop Rules

- 5 question sets, each with 3 personalized questions
- Win PDF, then another, then bonus feature
- Bonus only unlocked by purchasing MVP
- Final warning + Aura chat if last offer declined

---

## 🛠 Tables Used

| Table | Description |
|-------|-------------|
| user_profile | Auth & session info |
| loop_templates | Question sets |
| loop_builds | MVP creation steps |
| loop_components | PDFs, bonuses, triggers |
| loop_outcomes | Answers, timing, retries |
| contacts | Emails, names, tags |
| subscriptions | Stripe metadata & plan info |

---

## 🔐 Auth

- MCP Auth (default)
- A2A logic protects user path
- Optional fallback: email or Google

---

© 2025 BoDiGi™, Aura™, Boltz™ · All rights reserved
